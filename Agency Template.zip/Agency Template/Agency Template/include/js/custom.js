var $ = jQuery.noConflict();

jQuery(document).ready(function($){

/*==========================*/ 
/* sliders */ 
/*==========================*/
if($('.blog-slider').length > 0){
jQuery('.blog-slider').slick({
  slidesToShow: 3,
  slidesToScroll: 1,
  dots: true,
  arrows: true, 
  infinite: true, 
  centerMode: false, 
   responsive: [
    {
      breakpoint: 768,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1,
        adaptiveHeight: false
      }
    }
  ]
});
}

/*==========================*/ 
/* sliders */ 
/*==========================*/
if($('.testimonial-slider').length > 0){
jQuery('.testimonial-slider').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  dots:true,
  arrows:false, 
   // fade: true,
  infinite: true, 
  centerMode: false, 
  autoplay:true,
  autoplaySpeed: 6000,
  //  responsive: [
  //   {
  //     breakpoint: 768,
  //     settings: {
  //       slidesToShow: 1,
  //       slidesToScroll: 1,
  //       adaptiveHeight: false
  //     }
  //   }
  // ]
});
}
/*==========================*/ 
/* hero-sliders */ 
/*==========================*/
$(document).ready(function(){
  
  $(".hero-Slider").slick({
    autoplay:true,
    autoplaySpeed:10000,
    speed:600,
    slidesToShow:1,
    slidesToScroll:1,
    pauseOnHover:false,
    dots:true,
    pauseOnDotsHover:true,
    cssEase:'linear',
   fade:true,
    draggable:false,
     responsive: [
    {
      breakpoint: 768,
      settings: {
        arrows: false,
      }
    }
  ]
  });
  
})
/*==========================*/ 
/* sliders */ 
/*==========================*/
if($('.client-list').length > 0){
jQuery('.client-list').slick({
  slidesToShow:4,
  slidesToScroll:1,
  dots:false,
  arrows: true, 
  infinite: true, 
  centerMode: false, 
  autoplay:true,
  autoplaySpeed: 3000,
   responsive: [
    {
      breakpoint: 991,
      settings: {
        slidesToShow:3,
        slidesToScroll: 1,
        adaptiveHeight: false
      }
    },
    {
      breakpoint: 575,
      settings: {
        slidesToShow:2,
      }
    }
  ]
});
}
 
/*==========================*/  
/* Mobile Slider */  
/*==========================*/ 
if($('.mobile-slider').length > 0){
jQuery('.mobile-slider').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  dots: true,
  arrows: false, 
  infinite: true, 
  centerMode: false, 
  responsive: [
    {
      breakpoint: 5000,
      settings: "unslick"
    },
    {
      breakpoint: 768,
      settings: {
        arrows: false,
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: true,  
        adaptiveHeight: false
      }
    }
  ]
});
}
 

/*==========================*/  
/* Scroll on animate */  
/*==========================*/
function onScrollInit( items, trigger ) {
  items.each( function() {
    var osElement = $(this),
        osAnimationClass = osElement.attr('data-os-animation'),
        osAnimationDelay = osElement.attr('data-os-animation-delay');
        osElement.css({
          '-webkit-animation-delay':  osAnimationDelay,
          '-moz-animation-delay':     osAnimationDelay,
          'animation-delay':          osAnimationDelay
        });
        var osTrigger = ( trigger ) ? trigger : osElement;
        osTrigger.waypoint(function() {
          osElement.addClass('animated').addClass(osAnimationClass);
          },{
              triggerOnce: true,
              offset: '95%',
        });
// osElement.removeClass('fadeInUp');
  });
}
onScrollInit( $('.os-animation') );
onScrollInit( $('.staggered-animation'), $('.staggered-animation-container'));


/*==========================*/
/* Header fix */
/*==========================*/
var scroll = $(window).scrollTop();
if (scroll >= 10) {
    $("body").addClass("fixed");
} else {
    $("body").removeClass("fixed");
}


});


$(window).scroll(function() {
    var scroll = $(window).scrollTop();
    if (scroll >= 10) {
        $("body").addClass("fixed");
    } else {
        $("body").removeClass("fixed");
    }
});


jQuery(function ($) {
  var $items = $(".items .item");
  var $btns = $(".filter span").on("click", function () {
    var active = $btns
      .removeClass("current")
      .filter(this)
      .addClass("current")
      .data("filter");
    $items
      .hide()
      .filter("." + active)
      .fadeIn(450);
  });
});

 /*==========================*/
    /* Closes responsive menu when a scroll trigger link is clicked */
    /*==========================*/
    $('.js-scroll-trigger').click(function() {
        $('.navbar-collapse').collapse('hide');
    });

/*==========================*/
    /* tilt Effect */
    /*==========================*/
    $(document).ready(function() {
        $(document).on("scroll", onScroll);

        //smoothscroll
        $('a[href^="#"]').on('click', function(e) {
            e.preventDefault();
            $(document).off("scroll");

            $('a').each(function() {
                $(this).removeClass('active');
            })
            $(this).addClass('active');

            var target = this.hash,
                menu = target;
            $target = $(target);
            $('html, body').stop().animate({
                'scrollTop': $target.offset().top + 2
            }, 500, 'swing', function() {
                window.location.hash = target;
                $(document).on("scroll", onScroll);
            });
        });
    });

    function onScroll(event) {
        var scrollPos = $(document).scrollTop();
        $('.navbar-nav a').each(function() {
            var currLink = $(this);
            var refElement = $(currLink.attr("href"));
            if (refElement.position().top <= scrollPos && refElement.position().top + refElement.height() > scrollPos) {
                $('.navbar-nav li a').removeClass("active");
                currLink.addClass("active");
            } else {
                currLink.removeClass("active");
            }
        });
    }