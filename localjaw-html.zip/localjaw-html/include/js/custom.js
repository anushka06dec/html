gsap.utils.toArray(".hw-block").forEach((myBlock, i) => {
    const pinClass = $(myBlock).attr('data-title');
    ScrollTrigger.create({
        trigger: myBlock,
        start: "top 87px",
        end: 'bottom 87px',
        //markers:true,
        scrub: true,
        toggleClass: { targets: ".hw-dots-group", className: pinClass },
        invalidateOnRefresh: true,
    });


});



const vsText = gsap.utils.toArray('.hw-left');
vsText.forEach(vsText => {
    gsap.to(vsText, {
        opacity: 0,
        y: -150,
        duration: 1,
        ease: "power1.Out",
        scrollTrigger: {
            trigger: vsText,
            start: "top 87px",
            //end: "bottom 100%",
            scrub: true,
            //markers:true,

        }
    })
});



ScrollTrigger.matchMedia({
  
  // desktop
  "(min-width: 993px)": function() {
 
      gsap.utils.toArray(".hw-block:not(.last)").forEach((myBlock) => {

          const headerHeight = $('header').outerHeight();

          ScrollTrigger.create({
              trigger: myBlock,
              start: () => "top " + (headerHeight),
              end: 'bottom 87px',
              //markers: true,
              pin: true,
              pinSpacing: false,
              scrub: true,
              toggleClass: 'active',
              toggleActions: "play none reverse none",
              invalidateOnRefresh: true,
          });
      });
  }, 
  
  
});


if ($('.hw-dots').length > 0) {
    var vsdots = gsap.timeline();
    vsdots.from('.hw-dots', {
        scrollTrigger: {
            trigger: '.hw-dots',
            start: "top 87px",
            endTrigger: ".hw-section",
            end: "bottom bottom",
            scrub: true,
            pin: true,
            pinSpacing: false,
            //markers: true,

        }
    });
};




jQuery(document).ready(function($){
  // Show Hide DIV with TextBox based on CheckboxButton selection (checked unchecked).
$("#Check1").click(function () {
    if ($(this).is(":checked")) {
       
        $("#addEventlocation").show();
    } else {
       
        
        $("#addEventlocation").hide();
    }
});
$("#selectBox").change(function(){
  $(this).find("option:selected").each(function(){
      if($(this).attr("value")=="recurringDay"){
          $(".hide").show();
      }
      
      else{
          $(".hide").hide();
      }
  });
}).change();
/*==========================*/
/* Init masonry*/
/*==========================*/
var $grid = $('.grid').imagesLoaded( function() {
   $grid.masonry({
     itemSelector: '.grid-item',
     percentPosition: true,
     columnWidth: '.grid-sizer'
   }); 
 });
/*==========================*/
/* magnific-popup */
/*==========================*/
$(".events-gallery-box").on("click", function () {
    $(this).find(".gallery-item").magnificPopup("open");
});
$(".gallery-item").each(function () {
    $(this).magnificPopup({
        delegate: "a",
        type: "image",
        gallery: {
            enabled: true,
        },
        image: {
            titleSrc: 'title' 
            // this tells the script which attribute has your caption
        },
    });
});


 $(document).on('click', 'li.vrh-menu-item .dropdown-menu', function (e) {
  e.stopPropagation();
});

//tab selection with a dropdown list for small devices
// resize the fiddle window and run de script to see the result
$('#tab_selector').on('change', function (e) {
    $('.form-tabs li a').eq($(this).val()).tab('show');
});


$('body').on('click', function (e) {
  $('[data-toggle=popover]').each(function () {
      // hide any open popovers when the anywhere else in the body is clicked
      if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
          $(this).popover('hide');
      }
  });
});
  
$('.navbar-toggler').click(function(){
  $('body').toggleClass('menu-open');
});

$('#nav-icon,.hamburger').click(function(){
  $('body').toggleClass('sidebar-open');
});
// Tooltip init
 $('[data-toggle="tooltip"]').tooltip();
// Tooltip init
$('[data-toggle="popover"]').popover();
// nice select init
// $('select').niceSelect();
$('select:not(.ignore)').niceSelect();

$('.custom-dropdown-toggle').click(function(){
  $('.custom-dropdown-menu').toggleClass('show');
});



// password hide and show
$(".toggle-password").click(function() {

  $(this).toggleClass('toggle');

  var input = $($(this).attr("toggle"));
  if (input.attr("type") == "password") {
      input.attr("type", "text");
  } else {
      input.attr("type", "password");
  }
});


/*==========================*/ 
/* product-slider */ 
/*==========================*/

if($('.product-slider').length > 0){
jQuery('.product-slider').slick({
  slidesToShow: 4,
  slidesToScroll: 1,
  dots: false,
  arrows: true, 
  infinite: true, 
  responsive: [
        {
          breakpoint: 992,
          settings: { 
            slidesToShow: 2,
            slidesToScroll: 1,
          }
        },
        {
          breakpoint: 576,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows:false,
          }
        }
      ] 
   
})
}

/*==========================*/ 
/* product-slider */ 
/*==========================*/

if($('.gallery-slider').length > 0){
jQuery('.gallery-slider').slick({
  slidesToShow: 3,
  slidesToScroll: 1,
  dots: false,
  arrows: true,
   prevArrow: $('.prev1'),
     nextArrow: $('.next1'),
  infinite: true, 
  responsive: [
        {
          breakpoint: 992,
          settings: { 
            slidesToShow: 2,
            slidesToScroll: 1,
          }
        },
        {
          breakpoint: 576,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows:false,
          }
        }
      ] 
   
})
}

/*==========================*/  
/* logo slider */  
/*==========================*/
if($('.logo-slider').length > 0){
    $('.logo-slider').bxSlider({
      minSlides: 1,
      maxSlides: 9,
      slideMargin: 0,
      slideWidth: 165,
      ticker: true,
      speed: 30000,
      tickerHover:false,
    });
  }


/*==========================*/ 
/* category slider */ 
/*==========================*/
if($('.category-slider').length > 0){
jQuery('.category-slider').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  dots: true,
  arrows: false, 
  infinite: true, 
  centerMode: true, 
  responsive: [
    {
      breakpoint: 5000,
      settings: "unslick"
    },
    {
      breakpoint: 768,
      settings: {
        arrows: false,
        slidesToShow: 2,
        slidesToScroll: 1,
        dots: true,  
        adaptiveHeight: false,
        centerMode: true, 
      }
    },
    {
      breakpoint: 600,
      settings: {
        arrows: false,
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: true,  
        adaptiveHeight: false,
        centerMode: true, 
      }
    }  ]
});
}
/*==========================*/ 
/* Blog-slider */ 
/*==========================*/
if($('.blog-slider').length > 0){
jQuery('.blog-slider').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  dots: true,
  arrows: false, 
  infinite: true, 
  centerMode: false, 
  responsive: [
    {
      breakpoint: 5000,
      settings: "unslick"
    },
    {
      breakpoint: 768,
      settings: {
        arrows: false,
        slidesToShow: 2,
        slidesToScroll: 1,
        dots: true,  
        adaptiveHeight: false
      }
    },
    {
      breakpoint: 576,
      settings: {
        arrows: false,
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: true,

      }
    }
  ]
});
}

/*==========================*/ 
/* Map-slider */ 
/*==========================*/
$('.nearby-text-slider').slick({
    dots: true,
    dotsClass: 'custom-paging',
      customPaging: function (slider, i) {return  (i + 1) + '<span>of</span>' + slider.slideCount;
     },
    infinite: false,
    speed: 300,
    slidesToShow: 1,
    slidesToScroll: 1,
    rows:6,
    prevArrow: $('.prev'),
     nextArrow: $('.next')
     // responsive: [
     //    {
     //      breakpoint: 768,
     //      settings: { 
     //        slidesToShow: 1,
     //        slidesToScroll: 1,
     //        rows:4,
     //      }
     //    }
     //  ]
  });

// change button text 
$('.viewmore-btn[data-toggle="collapse"]').click(function() {
  $(this).toggleClass( "active" );
  if ($(this).hasClass("active")) {
    $(this).text(" View less about host");
  } else {
    $(this).text(" View more about host");
  }
});

// change button text 
$('.viewmore-btn.viewbtn2[data-toggle="collapse"]').click(function() {
  $(this).toggleClass( "active" );
   $('.add-shadow').toggleClass( "active" );

  if ($(this).hasClass("active")) {
    $(this).text(" View less");
  } else {
    $(this).text(" View more");
  }
});


/*==========================*/ 
/* post-event-slider */ 
/*==========================*/
if($('.post-event-list').length > 0){
jQuery('.post-event-list').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  dots: false,
  arrows: true, 
  infinite: true,
  prevArrow: $('.prev1'),
  nextArrow: $('.next1') , 
  responsive: [
        {
          breakpoint: 992,
          settings: { 
            slidesToShow: 1,
            slidesToScroll: 1,
          }
        },
        {
          breakpoint: 576,
          settings: { 
            slidesToShow: 1,
            slidesToScroll: 1,
            // arrows:false,
          }
        }
      ] 
   
})
}

/*==========================*/ 
/* musician-slider */ 
/*==========================*/
if($('.musician-slider').length > 0){
jQuery('.musician-slider').slick({
  slidesToShow: 4,
  slidesToScroll: 1,
  dots: false,
  // arrows: true, 
  infinite: true,
  prevArrow: $('.prev4'),
  nextArrow: $('.next4') ,
  responsive: [
        {
          breakpoint: 992,
          settings: { 
            slidesToShow: 2,
            slidesToScroll: 1,
          }
        },
        {
          breakpoint: 576,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows:false,
          }
        }
      ] 
   
})
}

/*==========================*/ 
/* real-estate-slider */ 
/*==========================*/
jQuery('.real-estate-slider').slick({
  slidesToShow: 4,
  slidesToScroll: 1,
  dots: false,
  arrows: true, 
  infinite: true,
   prevArrow: $('.prev3'),
  nextArrow: $('.next3') , 
  responsive: [
        {
          breakpoint: 992,
          settings: { 
            slidesToShow: 2,
            slidesToScroll: 1,
          }
        },
        {
          breakpoint: 576,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows:false,
          }
        }
      ] 
   
});

/*==========================*/ 
/* vacation-slider */ 
/*==========================*/
jQuery('.vacation-slider').slick({
  slidesToShow: 4,
  slidesToScroll: 1,
  dots: false,
  // arrows: true, 
  infinite: true,
  prevArrow: $('.prev2'),
  nextArrow: $('.next2') , 
  responsive: [
        {
          breakpoint: 992,
          settings: { 
            slidesToShow: 2,
            slidesToScroll: 1,
          }
        },
        {
          breakpoint: 576,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows:false,
          }
        }
      ] 
   
});
/*==========================*/ 
/* podcast-slider */ 
/*==========================*/
jQuery('.podcast-slider').slick({
  slidesToShow: 4,
  slidesToScroll: 1,
  dots: true,
  arrows: true, 
  infinite:false,
  // prevArrow: $('.prev2'),
  // nextArrow: $('.next2') , 
  responsive: [
        {
          breakpoint: 992,
          settings: { 
            slidesToShow: 2,
            slidesToScroll: 1,
          }
        },
        {
          breakpoint: 576,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows:false,
          }
        }
      ] 
   
});
/*==========================*/ 
/* sliders */ 
/*==========================*/
// if($('.simple-slider').length > 0){
// jQuery('.simple-slider').slick({
//   slidesToShow: 1,
//   slidesToScroll: 1,
//   dots: true,
//   arrows: false, 
//   infinite: true, 
//   centerMode: false, 
   
// });
// }
 
/*==========================*/  
/* Mobile Slider */  
/*==========================*/ 
if($('.wallpost-slider').length > 0){
jQuery('.wallpost-slider').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  dots: true,
  arrows: false, 
  infinite: true, 
  centerMode: false, 
  responsive: [
    {
      breakpoint: 5000,
      settings: "unslick"
    },
    {
      breakpoint: 768,
      settings: {
        arrows: false,
        slidesToShow: 2,
        slidesToScroll: 1,
        dots: true,  
        adaptiveHeight: false
      }
    },
    {
      breakpoint: 579,
      settings: {
        arrows: false,
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: true,  
        adaptiveHeight: false
      }
    }
  ]
});
}

/*==========================*/ 
/* blog-hero-slider-slider */ 
/*==========================*/
jQuery('.blog-hero-slide').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplay: false,
  autoplaySpeed: 2000,
  dots: false,
  arrows: false, 
  infinite: true,
  
});

// Sticky header on scroll
$('#list-tabs').waypoint(function(direction) {
  $('#scrollspy-list').toggleClass('tabs-fixed');
},{ 
  offset: '100'
});

$('#list-tabs > li > a').click(function(){
    var id = $(this).attr('href');
    $(id).slideDown();
    $('html, body').animate({scrollTop: $(id).offset().top - 100}, 300);
    return false;
});
 

/*==========================*/  
/* Scroll on animate */  
/*==========================*/
function onScrollInit( items, trigger ) {
  items.each( function() {
    var osElement = $(this),
        osAnimationClass = osElement.attr('data-os-animation'),
        osAnimationDelay = osElement.attr('data-os-animation-delay');
        osElement.css({
          '-webkit-animation-delay':  osAnimationDelay,
          '-moz-animation-delay':     osAnimationDelay,
          'animation-delay':          osAnimationDelay
        });
        var osTrigger = ( trigger ) ? trigger : osElement;
        osTrigger.waypoint(function() {
          osElement.addClass('animated').addClass(osAnimationClass);
          },{
              triggerOnce: true,
              offset: '95%',
        });
// osElement.removeClass('fadeInUp');
  });
}
onScrollInit( $('.os-animation') );
onScrollInit( $('.staggered-animation'), $('.staggered-animation-container'));


/*==========================*/
/* Header fix */
/*==========================*/
var scroll = $(window).scrollTop();
if (scroll >= 10) {
    $("body").addClass("fixed");
} else {
    $("body").removeClass("fixed");
}


});


$(window).scroll(function() {
    var scroll = $(window).scrollTop();
    if (scroll >= 10) {
        $("body").addClass("fixed");
    } else {
        $("body").removeClass("fixed");
    }
});




$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
  $('.product-slider').slick('setPosition');
})



/*************************** dropdownr Propagation ***************************************/
    $('.dropdown-menu').click(function(e){
       e.stopPropagation();
    })

    /*************************** Range slider ***************************************/
    var $range1 = $(".js-range-slider");
        $range1.ionRangeSlider({
          type: "double",
          min: 0,
          max: 1000,
          from: 0,
          to: 500
        });
        $range1.on("change", function () {
          var $inp = $(this);
          var v = $inp.prop("value");     // input value in format FROM;TO
          var from = $inp.data("from");   // input data-from attribute
          var to = $inp.data("to");       // input data-to attribute
          $('.vrh-range-contaienr #minValue').val(from);
          $('.vrh-range-contaienr #maxValue').val(to);
    });

    /*************************** ADD 1+ ***************************************/
    $(".quantity-button").on("click", function() {
          var $button = $(this);
          var oldValue = $button.parent().find("input").val();
          $button.blur();
          if ($button.hasClass("inc")) {
              var newVal = parseFloat(oldValue) + 1;
            } else {
           // Don't allow decrementing below zero
            if (oldValue > 0) {
              var newVal = parseFloat(oldValue) - 1;
            } else {
              newVal = 0;
            }
          }
          $button.parent().find("input").val(newVal);
    }); 