jQuery(document).ready(function($){

/*==========================*/  
/* patients  Slider */  
/*==========================*/ 
$('.hero-text-slider').slick({
    dots: false,
    infinite: true,
    arrows: true,
    autoplay: false,
    autoplaySpeed: 3000,
    speed: 1500,
    fade: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    asNavFor: '.hero-img-slider',
    focusOnSelect: true,
    responsive: [{
        breakpoint: 768,
        settings: {
            dots: false,
            arrows: true
        }
    }]
});
$('.hero-img-slider').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: false,
    autoplaySpeed: 3000,
    fade: false,
    speed: 1500,
    dots: false,
    arrows: false,
    asNavFor: '.hero-text-slider',
    responsive: [{
        breakpoint: 768,
        settings: {
            dots: false,
            arrows: false
        }
    }]
});
 
/*==========================*/  
/* mobile-slider */  
/*==========================*/ 
if($('.mobile-slider').length > 0){
jQuery('.mobile-slider').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  dots: false,
  arrows: false, 
  infinite: false, 
  centerMode: false, 
  responsive: [
    {
      breakpoint: 5000,
      settings: "unslick"
    },
    {
      breakpoint: 768,
      settings: {
        arrows: false,
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: true,  
        adaptiveHeight: true
      }
    }
  ]
});
}

/*==========================*/
/* TABLE WRAP */
/*==========================*/
$(".table-wrap").each(function() {
   var nmtTable = $(this);
   var nmtHeadRow = nmtTable.find("thead tr");
   nmtTable.find("tbody tr").each(function() {
     var curRow = $(this);
     for (var i = 0; i < curRow.find("td").length; i++) {
       var rowSelector = "td:eq(" + i + ")";
       var headSelector = "th:eq(" + i + ")";
       curRow.find(rowSelector).attr('data-title', nmtHeadRow.find(headSelector).text());
     }
   });
 });

/*==========================*/  
/* Scroll on animate */  
/*==========================*/
function onScrollInit( items, trigger ) {
  items.each( function() {
    var osElement = $(this),
        osAnimationClass = osElement.attr('data-os-animation'),
        osAnimationDelay = osElement.attr('data-os-animation-delay');
        osElement.css({
          '-webkit-animation-delay':  osAnimationDelay,
          '-moz-animation-delay':     osAnimationDelay,
          'animation-delay':          osAnimationDelay
        });
        var osTrigger = ( trigger ) ? trigger : osElement;
        osTrigger.waypoint(function() {
          osElement.addClass('animated').addClass(osAnimationClass);
          },{
              triggerOnce: true,
              offset: '95%',
        });
// osElement.removeClass('fadeInUp');
  });
}
onScrollInit( $('.os-animation') );
onScrollInit( $('.staggered-animation'), $('.staggered-animation-container'));


/*==========================*/
/* Header fix */
/*==========================*/
var scroll = $(window).scrollTop();
if (scroll >= 2) {
    $("body").addClass("fixed");
} else {
    $("body").removeClass("fixed");
}


});


$(window).scroll(function() {
    var scroll = $(window).scrollTop();
    if (scroll >= 2) {
        $("body").addClass("fixed");
    } else {
        $("body").removeClass("fixed");
    }
});