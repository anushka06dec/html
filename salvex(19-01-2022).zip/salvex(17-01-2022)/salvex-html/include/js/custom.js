    // Cache our vars for the fixed sidebar on scroll
    // var $sidebar = $('#sidebar-nav');

    // var sidebarTop = $sidebar.position().top - 200;
    // var blogHeight = $('#content').outerHeight() - 10;


    // $(window).scroll(fixSidebarOnScroll);


    // function fixSidebarOnScroll() {
      
    //     var windowScrollTop = $(window).scrollTop();


    //     if (windowScrollTop >= blogHeight || windowScrollTop <= sidebarTop) {
          
    //         $sidebar.removeClass('sticky');
    //     }
   
    //     else if (windowScrollTop >= sidebarTop) {
          
    //         if (!$sidebar.hasClass('sticky')) {
    //             $sidebar.addClass('sticky');
    //         }
    //     }
    // }





// Prevent event bubble up to window.
document.addEventListener("DOMContentLoaded", function() {
    /////// Prevent closing from click inside dropdown
    document.querySelectorAll('.dropdown-menu').forEach(function(element) {
        element.addEventListener('click', function(e) {
            e.stopPropagation();
        });
    })
});
// DOMContentLoaded  end




var stepTime = 20;
var docBody = document.body;
var focElem = document.documentElement;

var scrollAnimationStep = function (initPos, stepAmount) {
    var newPos = initPos - stepAmount > 0 ? initPos - stepAmount : 0;

    docBody.scrollTop = focElem.scrollTop = newPos;

    newPos && setTimeout(function () {
        scrollAnimationStep(newPos, stepAmount);
    }, stepTime);
}

var scrollTopAnimated = function (speed) {
    var topOffset = docBody.scrollTop || focElem.scrollTop;
    var stepAmount = topOffset;

    speed && (stepAmount = (topOffset * stepTime)/speed);

    scrollAnimationStep(topOffset, stepAmount);
};






// Toggle Dasboard SideNav
function toggleNavMenu() {
    var element = document.getElementsByTagName("body")[0];
    element.classList.toggle('open-menu');
    var val = document.getElementsByClassName("menu-dropdown");
    var i;
    for (j = 0; j < val.length; j++) {
        val[j].classList.toggle('dropdown-menu');
    }
}

// Custom Drodpdown Hide/Show.
var divs = ["dropDownCategories", "dropDownRegions"];
var visibleDivId = null;

function toggleVisibility(divId) {
    if (visibleDivId === divId) {
        visibleDivId = null;
    } else {
        visibleDivId = divId;
    }
    hideNonVisibleDivs();
}

function hideNonVisibleDivs() {
    var i, divId, div;
    for (i = 0; i < divs.length; i++) {
        divId = divs[i];
        div = document.getElementById(divId);

        if (visibleDivId === divId) {
            div.classList.toggle("show");
        } else {
            div.classList.remove("show");
        }
    }
}


// Header fixed on scroll.
window.onscroll = function() {
    myFunction()
};
var body = document.getElementsByTagName("body")[0];
var sticky = body.offsetTop + 50;

function myFunction() {
    if (window.pageYOffset > sticky) {
        body.classList.add("fixed");
    } else {
        body.classList.remove("fixed");
    }
}


// Show/Hide password through javascript
function showPwd(id, el) {
    let x = document.getElementById(id);
    if (x.type === "password") {
        x.type = "text";
        el.src = "include/images/eye-off.svg";
    } else {
        x.type = "password";
        el.src = "include/images/eye.svg";
    }
}




var $ = jQuery.noConflict();

jQuery(document).ready(function($) {

    // $('select:not(.ignore)').niceSelect();

    $('.product-slider').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        fade: false,
        asNavFor: '.thumbnails-slider'
    });
    $('.thumbnails-slider').slick({
        slidesToShow: 4,
        slidesToScroll: 1,
        asNavFor: '.product-slider',
        dots: false,
        arrows: true,
        focusOnSelect: true,
        responsive: [{
            breakpoint: 991,
            settings: {
                infinite: true,
                dots: false,
                arrows: false
            }
        }]
    });


    $('.offshore-slider').slick({
        dots: false,
        infinite: true,
        speed: 300,
        slidesToShow: 4,
        slidesToScroll: 1,
        responsive: [{
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: false,
                    arrows: false
                }
            },
            {
                breakpoint: 767,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    arrows: false
                }
            }
        ]
    });

    $('.home-offshore-slider').slick({
        dots: false,
        infinite: false,
        speed: 300,
        slidesToShow: 3,
        slidesToScroll: 1,
        responsive: [{
            breakpoint: 991,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
                infinite: false,
                dots: false,
                arrows: false
            }
        }, {
            breakpoint: 768,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
                infinite: false,
                dots: false,
                arrows: false
            }
        }, {
            breakpoint: 579,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
                infinite: false,
                dots: false,
                arrows: false
            }
        }]
    });

    $('.oil-and-gas-slider').slick({
        dots: false,
        infinite: true,
        speed: 300,
        slidesToShow: 4,
        slidesToScroll: 1,
        responsive: [{
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: false,
                    arrows: false
                }
            },
            {
                breakpoint: 767,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    arrows: false
                }
            }
        ]
    });


    $('.category-slider').slick({
        infinite: false,
        speed: 300,
        slidesToShow: 6,
        slidesToScroll: 1,
        responsive: [{
                breakpoint: 1024,
                settings: {
                    slidesToShow: 5,
                    slidesToScroll: 1,
                    infinite: true
                }
            },
            {
                breakpoint: 991,
                settings: {
                    slidesToShow: 4,
                    slidesToScroll: 1,
                    arrows: false
                }
            },
            {
                breakpoint: 579,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    arrows: false
                }
            }
        ]
    });


});