var $ = jQuery.noConflict();
jQuery(document).ready(function($) {

/*==========================*/
/* sliders */
/*==========================*/
if ($('.hero-slider > div').length > 1) {
    jQuery('.hero-slider').slick({
        dots: true,
        infinite: true,
        arrows: false,
        autoplay: false,
        autoplaySpeed: 4000,
        speed: 300,
        asNavFor: '.hero-image-slider',
        focusOnSelect: true
    });
    $('.hero-image-slider').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplaySpeed: 4000,
        speed: 300,
        arrows: false,
        asNavFor: '.hero-slider'
    });
}
if ($('.home-case-slider > div').length > 1) {
    jQuery('.home-case-slider').slick({
        dots: true,
        infinite: true,
        arrows: true,
        autoplay: false,
        autoplaySpeed: 4000,
        speed: 300
    });
}

/*==========================*/
/* Mobile Slider */
/*==========================*/
if ($('.mobile-slider').length > 0) {
    jQuery('.mobile-slider').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: true,
        arrows: false,
        infinite: true,
        centerMode: false,
        responsive: [{
                breakpoint: 5000,
                settings: "unslick"
            },
            {
                breakpoint: 768,
                settings: {
                    arrows: false,
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    dots: true,
                    adaptiveHeight: false
                }
            }
        ]
    });
}

/*==========================*/
/* Scroll on animate */
/*==========================*/
function onScrollInit(items, trigger) {
    items.each(function() {
        var osElement = $(this),
            osAnimationClass = osElement.attr('data-os-animation'),
            osAnimationDelay = osElement.attr('data-os-animation-delay');
        osElement.css({
            '-webkit-animation-delay': osAnimationDelay,
            '-moz-animation-delay': osAnimationDelay,
            'animation-delay': osAnimationDelay
        });
        var osTrigger = (trigger) ? trigger : osElement;
        osTrigger.waypoint(function() {
            osElement.addClass('animated').addClass(osAnimationClass);
        }, {
            triggerOnce: true,
            offset: '95%',
        });
        // osElement.removeClass('fadeInUp');
    });
}
onScrollInit($('.os-animation'));
onScrollInit($('.staggered-animation'), $('.staggered-animation-container'));

/*==========================*/
/* scroll down */
/*==========================*/
$('.intro-scroll-down').click(function() {

    var headerHeight = $('header').outerHeight();
    console.log(headerHeight);
    var scrolltarget = $(this).data('section');
    $('html, body').animate({
        scrollTop: $('#' + scrolltarget).offset().top - 90
    }, 500);
    return false;

});

/*==========================*/
/* Header fix */
/*==========================*/
var scroll = $(window).scrollTop();
if (scroll >= 10) {
    $("body").addClass("fixed");
} else {
    $("body").removeClass("fixed");
}


});


$(window).scroll(function() {
    var scroll = $(window).scrollTop();
    if (scroll >= 10) {
        $("body").addClass("fixed");
    } else {
        $("body").removeClass("fixed");
    }
});